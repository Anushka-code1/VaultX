/* ============================================================
   VAULTX — app.js
   Connects to Python backend (FastAPI) running on localhost:8000
   ============================================================ */

const API = 'http://localhost:8000';

/* ─────────────────────────────────────────────
   STATE
───────────────────────────────────────────── */
let allFiles        = [];
let filteredFiles   = [];
let selectedFiles   = [];   // pending upload queue
let currentFilter   = 'all';
let currentLayout   = 'grid';
let activityLog     = [];
const MAX_STORAGE_GB = 5;   // Azure free tier ~5 GB

/* ─────────────────────────────────────────────
   INIT
───────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  checkConnection();
  loadDashboard();
});

/* ─────────────────────────────────────────────
   CONNECTION CHECK
───────────────────────────────────────────── */
async function checkConnection() {
  const dot  = document.getElementById('statusDot');
  const text = document.getElementById('statusText');
  try {
    const res = await fetch(`${API}/health`, { signal: AbortSignal.timeout(4000) });
    if (res.ok) {
      dot.className  = 'status-dot online';
      text.textContent = 'Azure SQL Connected';
    } else throw new Error('non-ok');
  } catch {
    dot.className  = 'status-dot offline';
    text.textContent = 'Backend Offline';
    showToast('Backend not reachable — running in demo mode', 'error');
    seedDemoData();
  }
}

/* ─────────────────────────────────────────────
   DEMO DATA (when backend is offline)
───────────────────────────────────────────── */
function seedDemoData() {
  const now = Date.now();
  allFiles = [
    { id:1, name:'project_brief.pdf',    size:2048576,   type:'document', uploaded_at: new Date(now - 86400000*2).toISOString(), description:'Q4 project brief', tags:'work,pdf' },
    { id:2, name:'hero_banner.png',      size:5242880,   type:'image',    uploaded_at: new Date(now - 86400000).toISOString(),   description:'Marketing asset',  tags:'design,image' },
    { id:3, name:'database_backup.sql',  size:10485760,  type:'other',    uploaded_at: new Date(now - 3600000*5).toISOString(),  description:'Weekly DB backup', tags:'backup,db' },
    { id:4, name:'promo_video.mp4',      size:52428800,  type:'video',    uploaded_at: new Date(now - 3600000*2).toISOString(),  description:'Promo clip',       tags:'video,marketing' },
    { id:5, name:'team_photo.jpg',       size:3145728,   type:'image',    uploaded_at: new Date(now - 7200000).toISOString(),    description:'Team outing',      tags:'photo' },
    { id:6, name:'invoice_oct.docx',     size:512000,    size:512000,     type:'document', uploaded_at: new Date(now - 1800000).toISOString(), description:'October invoice', tags:'finance,invoice' },
    { id:7, name:'soundtrack.mp3',       size:8388608,   type:'audio',    uploaded_at: new Date(now - 900000).toISOString(),     description:'Background music', tags:'audio' },
    { id:8, name:'source_code.zip',      size:15728640,  type:'archive',  uploaded_at: new Date(now - 600000).toISOString(),     description:'Source archive',   tags:'code,archive' },
  ];
  activityLog = [
    { action:'upload', file:'hero_banner.png',      time: new Date(now - 86400000).toISOString() },
    { action:'upload', file:'project_brief.pdf',    time: new Date(now - 86400000*2).toISOString() },
    { action:'delete', file:'old_report.xlsx',      time: new Date(now - 86400000*3).toISOString() },
    { action:'view',   file:'database_backup.sql',  time: new Date(now - 3600000*5).toISOString() },
    { action:'upload', file:'promo_video.mp4',      time: new Date(now - 3600000*2).toISOString() },
  ];
  renderDashboard();
}

/* ─────────────────────────────────────────────
   LOAD DASHBOARD
───────────────────────────────────────────── */
async function loadDashboard() {
  try {
    const [filesRes, actRes] = await Promise.all([
      fetch(`${API}/files`),
      fetch(`${API}/activity`)
    ]);
    allFiles    = await filesRes.json();
    activityLog = await actRes.json();
  } catch {
    /* will fall back to demo data from seedDemoData() */
  }
  filteredFiles = [...allFiles];
  renderDashboard();
}

/* ─────────────────────────────────────────────
   RENDER DASHBOARD
───────────────────────────────────────────── */
function renderDashboard() {
  const totalBytes = allFiles.reduce((s, f) => s + f.size, 0);
  const usedGB     = totalBytes / 1e9;
  const freeGB     = MAX_STORAGE_GB - usedGB;
  const pct        = Math.min((usedGB / MAX_STORAGE_GB) * 100, 100);

  /* stats */
  const today = new Date().toDateString();
  const todayUploads = allFiles.filter(f => new Date(f.uploaded_at).toDateString() === today).length;

  document.getElementById('stat-total').textContent = allFiles.length;
  document.getElementById('stat-used').textContent  = fmtSize(totalBytes);
  document.getElementById('stat-free').textContent  = fmtGB(freeGB);
  document.getElementById('stat-today').textContent = todayUploads;

  /* sidebar bar */
  document.getElementById('sidebarUsageBar').style.width = `${pct}%`;
  document.getElementById('sidebarUsageText').textContent = `${usedGB.toFixed(2)} / ${MAX_STORAGE_GB} GB`;

  /* upload view bar */
  document.getElementById('uploadStorageBar').style.width = `${pct}%`;
  document.getElementById('uploadStorageVal').textContent = `${usedGB.toFixed(2)} GB used of ${MAX_STORAGE_GB} GB`;

  /* donut */
  renderDonut(totalBytes);

  /* recent files */
  renderRecentFiles();
  renderFilesGrid();
  renderActivity();
}

/* ─────────────────────────────────────────────
   DONUT CHART
───────────────────────────────────────────── */
function renderDonut(totalBytes) {
  const circ = 2 * Math.PI * 50; // r=50 → 314.16

  const groups = { image: 0, document: 0, other: 0 };
  allFiles.forEach(f => {
    if      (f.type === 'image')    groups.image    += f.size;
    else if (f.type === 'document') groups.document += f.size;
    else                            groups.other    += f.size;
  });

  const maxBytes = MAX_STORAGE_GB * 1e9;
  const imgPct   = groups.image    / maxBytes;
  const docPct   = groups.document / maxBytes;
  const othPct   = groups.other    / maxBytes;
  const usedPct  = Math.min((imgPct + docPct + othPct), 1);

  /* stacked dashes */
  const imgLen = circ * imgPct;
  const docLen = circ * docPct;
  const othLen = circ * othPct;

  setDonutArc('donutImages', imgLen,               0,               circ);
  setDonutArc('donutDocs',   docLen,  -(imgLen),                    circ);
  setDonutArc('donutOther',  othLen,  -(imgLen + docLen),           circ);

  document.getElementById('donutPct').textContent = `${Math.round(usedPct * 100)}%`;

  document.getElementById('leg-images').textContent = fmtSize(groups.image);
  document.getElementById('leg-docs').textContent   = fmtSize(groups.document);
  document.getElementById('leg-other').textContent  = fmtSize(groups.other);
}

function setDonutArc(id, len, offset, circ) {
  const el = document.getElementById(id);
  if (!el) return;
  el.style.strokeDasharray  = `${len} ${circ - len}`;
  el.style.strokeDashoffset = offset;
}

/* ─────────────────────────────────────────────
   RECENT FILES (dashboard)
───────────────────────────────────────────── */
function renderRecentFiles() {
  const el = document.getElementById('recentFilesList');
  const recent = [...allFiles]
    .sort((a, b) => new Date(b.uploaded_at) - new Date(a.uploaded_at))
    .slice(0, 6);

  if (!recent.length) { el.innerHTML = '<div class="loading-row">No files yet</div>'; return; }

  el.innerHTML = recent.map(f => `
    <div class="mini-file" onclick="openFileModal(${f.id})">
      <div class="mini-file-icon" style="background:${typeColor(f.type, 'dim')}">${typeIcon(f.type)}</div>
      <div class="mini-file-name">${esc(f.name)}</div>
      <div class="mini-file-size">${fmtSize(f.size)}</div>
      <div class="mini-file-date">${timeAgo(f.uploaded_at)}</div>
    </div>
  `).join('');
}

/* ─────────────────────────────────────────────
   FILES GRID / LIST
───────────────────────────────────────────── */
function renderFilesGrid() {
  const el = document.getElementById('filesGrid');
  const list = currentFilter === 'all'
    ? filteredFiles
    : filteredFiles.filter(f => f.type === currentFilter);

  if (!list.length) {
    el.innerHTML = '<div class="loading-row">No files found</div>';
    return;
  }

  const isList = currentLayout === 'list';
  el.className = `files-grid${isList ? ' list-layout' : ''}`;

  el.innerHTML = list.map(f => `
    <div class="file-card${isList ? ' list-item' : ''}" onclick="openFileModal(${f.id})">
      <div class="file-thumb" style="background:${typeColor(f.type, 'dim')}">${typeIcon(f.type)}</div>
      <div class="file-card-name">${esc(f.name)}</div>
      ${isList ? `<div class="file-card-date">${timeAgo(f.uploaded_at)}</div>` : ''}
      <div class="file-card-size">${fmtSize(f.size)}</div>
    </div>
  `).join('');
}

/* ─────────────────────────────────────────────
   ACTIVITY LOG
───────────────────────────────────────────── */
function renderActivity() {
  const el = document.getElementById('activityList');
  if (!activityLog.length) {
    el.innerHTML = '<div class="loading-row">No activity yet</div>';
    return;
  }
  el.innerHTML = activityLog.map(a => {
    const icons = { upload: '⬆', delete: '🗑', view: '👁', download: '⬇' };
    return `
      <div class="activity-item">
        <div class="act-icon ${a.action}">${icons[a.action] || '◆'}</div>
        <div class="act-body">
          <div class="act-text">
            ${a.action === 'upload' ? 'Uploaded' : a.action === 'delete' ? 'Deleted' : 'Viewed'}
            <strong>${esc(a.file)}</strong>
          </div>
          <div class="act-time">${timeAgo(a.time)}</div>
        </div>
      </div>
    `;
  }).join('');
}

/* ─────────────────────────────────────────────
   SEARCH
───────────────────────────────────────────── */
function searchFiles(query) {
  const q = query.toLowerCase().trim();
  filteredFiles = q
    ? allFiles.filter(f =>
        f.name.toLowerCase().includes(q) ||
        (f.tags || '').toLowerCase().includes(q) ||
        (f.description || '').toLowerCase().includes(q)
      )
    : [...allFiles];
  renderFilesGrid();
}

/* ─────────────────────────────────────────────
   FILTER TABS
───────────────────────────────────────────── */
function filterFiles(type, btn) {
  currentFilter = type;
  document.querySelectorAll('.filter-tab').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderFilesGrid();
}

/* ─────────────────────────────────────────────
   LAYOUT TOGGLE
───────────────────────────────────────────── */
function setFilesLayout(layout, btn) {
  currentLayout = layout;
  document.querySelectorAll('.icon-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderFilesGrid();
}

/* ─────────────────────────────────────────────
   VIEW SWITCH
───────────────────────────────────────────── */
function switchView(name, btn) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
  document.getElementById(`view-${name}`).classList.add('active');
  if (btn) btn.classList.add('active');

  const titles = { dashboard: 'Dashboard', files: 'Files', upload: 'Upload File', activity: 'Activity Log' };
  document.getElementById('pageTitle').textContent = titles[name] || name;

  if (name === 'files') { filteredFiles = [...allFiles]; renderFilesGrid(); }
}

/* ─────────────────────────────────────────────
   DRAG & DROP / FILE SELECT
───────────────────────────────────────────── */
function handleDragOver(e) {
  e.preventDefault();
  document.getElementById('dropZone').classList.add('drag-over');
}
function handleDragLeave(e) {
  document.getElementById('dropZone').classList.remove('drag-over');
}
function handleDrop(e) {
  e.preventDefault();
  document.getElementById('dropZone').classList.remove('drag-over');
  addFilesToQueue([...e.dataTransfer.files]);
}
function handleFileSelect(e) {
  addFilesToQueue([...e.target.files]);
}

function addFilesToQueue(files) {
  const MAX = 50 * 1024 * 1024;
  files.forEach(f => {
    if (f.size > MAX) { showToast(`${f.name} exceeds 50 MB limit`, 'error'); return; }
    if (!selectedFiles.find(x => x.name === f.name && x.size === f.size)) {
      selectedFiles.push(f);
    }
  });
  renderQueue();
}

function removeFromQueue(idx) {
  selectedFiles.splice(idx, 1);
  renderQueue();
}

function renderQueue() {
  const el = document.getElementById('uploadQueue');
  const metaWrap = document.getElementById('uploadMetaWrap');

  if (!selectedFiles.length) {
    el.innerHTML = '';
    metaWrap.style.display = 'none';
    return;
  }

  metaWrap.style.display = 'flex';
  el.innerHTML = selectedFiles.map((f, i) => `
    <div class="queue-item">
      <span>${typeIcon(guessType(f.name))}</span>
      <span class="queue-item-name">${esc(f.name)}</span>
      <span class="queue-item-size">${fmtSize(f.size)}</span>
      <button class="queue-item-remove" onclick="removeFromQueue(${i})">✕</button>
    </div>
  `).join('');
}

/* ─────────────────────────────────────────────
   SUBMIT UPLOAD
───────────────────────────────────────────── */
async function submitUpload() {
  if (!selectedFiles.length) { showToast('No files selected', 'error'); return; }

  const btn  = document.getElementById('uploadSubmitBtn');
  const desc = document.getElementById('uploadDesc').value.trim();
  const tags = document.getElementById('uploadTags').value.trim();

  btn.disabled = true;
  btn.textContent = 'Uploading...';

  let successCount = 0;

  for (const file of selectedFiles) {
    try {
      const fd = new FormData();
      fd.append('file', file);
      fd.append('description', desc);
      fd.append('tags', tags);

      const res = await fetch(`${API}/files/upload`, { method: 'POST', body: fd });

      if (res.ok) {
        const uploaded = await res.json();
        allFiles.unshift(uploaded);
        activityLog.unshift({ action: 'upload', file: file.name, time: new Date().toISOString() });
        successCount++;
      } else {
        // Demo mode — fake insert
        fakeDemoUpload(file, desc, tags);
        successCount++;
      }
    } catch {
      fakeDemoUpload(file, desc, tags);
      successCount++;
    }
  }

  selectedFiles = [];
  document.getElementById('uploadDesc').value = '';
  document.getElementById('uploadTags').value = '';
  document.getElementById('fileInput').value  = '';
  renderQueue();

  btn.disabled = false;
  btn.textContent = 'Upload to Vault';

  showToast(`${successCount} file${successCount > 1 ? 's' : ''} uploaded successfully`);
  filteredFiles = [...allFiles];
  renderDashboard();
}

function fakeDemoUpload(file, desc, tags) {
  const id = Date.now();
  allFiles.unshift({
    id,
    name: file.name,
    size: file.size,
    type: guessType(file.name),
    uploaded_at: new Date().toISOString(),
    description: desc,
    tags
  });
  activityLog.unshift({ action: 'upload', file: file.name, time: new Date().toISOString() });
}

/* ─────────────────────────────────────────────
   FILE MODAL
───────────────────────────────────────────── */
function openFileModal(id) {
  const f = allFiles.find(x => x.id === id);
  if (!f) return;

  activityLog.unshift({ action: 'view', file: f.name, time: new Date().toISOString() });
  renderActivity();

  document.getElementById('modalTitle').textContent = f.name;
  document.getElementById('modalBody').innerHTML = `
    <div style="text-align:center;padding:16px 0 20px;font-size:40px">${typeIcon(f.type)}</div>
    ${row('File Name', esc(f.name))}
    ${row('Type', f.type.toUpperCase())}
    ${row('Size', fmtSize(f.size))}
    ${row('Uploaded', new Date(f.uploaded_at).toLocaleString())}
    ${row('Description', f.description || '—')}
    ${row('Tags', f.tags || '—')}
    <div class="download-progress-wrap" id="downloadProgressWrap">
      <div class="download-progress-label">
        <span>Downloading...</span>
        <span id="downloadPct">0%</span>
      </div>
      <div class="download-bar-wrap">
        <div class="download-bar" id="downloadBar"></div>
      </div>
    </div>
  `;

  document.getElementById('modalDeleteBtn').onclick  = () => deleteFile(id);
  document.getElementById('modalDownloadBtn').onclick = () => downloadFile(f);
  document.getElementById('modalOverlay').classList.add('open');
}

/* ─────────────────────────────────────────────
   DOWNLOAD FILE
───────────────────────────────────────────── */
async function downloadFile(f) {
  const btn       = document.getElementById('modalDownloadBtn');
  const progressWrap = document.getElementById('downloadProgressWrap');
  const bar       = document.getElementById('downloadBar');
  const pctLabel  = document.getElementById('downloadPct');

  btn.disabled = true;
  progressWrap.classList.add('visible');

  /* ── Try backend first ── */
  try {
    const res = await fetch(`${API}/files/${f.id}/download`);
    if (!res.ok) throw new Error('not-ok');

    const total    = parseInt(res.headers.get('Content-Length') || '0', 10);
    const reader   = res.body.getReader();
    const chunks   = [];
    let received   = 0;

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
      received += value.length;

      const pct = total ? Math.round((received / total) * 100) : 50;
      bar.style.width  = `${pct}%`;
      pctLabel.textContent = `${pct}%`;
    }

    bar.style.width  = '100%';
    pctLabel.textContent = '100%';

    const blob = new Blob(chunks);
    triggerBrowserDownload(blob, f.name);
    activityLog.unshift({ action: 'download', file: f.name, time: new Date().toISOString() });
    renderActivity();
    showToast(`Downloaded "${f.name}"`);

  } catch {
    /* ── Demo mode: fake download of a generated text file ── */
    simulateDemoDownload(f, bar, pctLabel);
    return; // early return, cleanup handled inside simulate
  }

  setTimeout(() => {
    progressWrap.classList.remove('visible');
    bar.style.width = '0%';
    btn.disabled = false;
  }, 800);
}

function triggerBrowserDownload(blob, filename) {
  const url  = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href     = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

function simulateDemoDownload(f, bar, pctLabel) {
  /* In demo mode (no backend), generate a placeholder file so the
     download still works and the user can see the full flow. */
  const btn          = document.getElementById('modalDownloadBtn');
  const progressWrap = document.getElementById('downloadProgressWrap');
  let   pct          = 0;

  const interval = setInterval(() => {
    pct += Math.floor(Math.random() * 20) + 10;
    if (pct >= 100) {
      pct = 100;
      clearInterval(interval);

      bar.style.width      = '100%';
      pctLabel.textContent = '100%';

      // create a small demo text blob
      const content = [
        `VAULTX — Demo Download`,
        `═══════════════════════`,
        `File:        ${f.name}`,
        `Type:        ${f.type}`,
        `Size:        ${fmtSize(f.size)}`,
        `Uploaded:    ${new Date(f.uploaded_at).toLocaleString()}`,
        `Description: ${f.description || '—'}`,
        `Tags:        ${f.tags || '—'}`,
        ``,
        `⚠  This is a demo placeholder.`,
        `   Connect the Python backend to download the real file.`,
      ].join('\n');

      const blob = new Blob([content], { type: 'text/plain' });
      triggerBrowserDownload(blob, f.name + '.demo.txt');

      activityLog.unshift({ action: 'download', file: f.name, time: new Date().toISOString() });
      renderActivity();
      showToast(`Demo download complete — connect backend for real files`);

      setTimeout(() => {
        progressWrap.classList.remove('visible');
        bar.style.width = '0%';
        btn.disabled    = false;
      }, 800);
    } else {
      bar.style.width      = `${pct}%`;
      pctLabel.textContent = `${pct}%`;
    }
  }, 180);
}

function row(key, val) {
  return `<div class="detail-row"><span class="detail-key">${key}</span><span class="detail-val">${val}</span></div>`;
}

function closeModal() {
  document.getElementById('modalOverlay').classList.remove('open');
}

/* ─────────────────────────────────────────────
   DELETE FILE
───────────────────────────────────────────── */
async function deleteFile(id) {
  const f = allFiles.find(x => x.id === id);
  if (!f) return;

  try {
    await fetch(`${API}/files/${id}`, { method: 'DELETE' });
  } catch { /* demo mode */ }

  allFiles     = allFiles.filter(x => x.id !== id);
  filteredFiles = filteredFiles.filter(x => x.id !== id);
  activityLog.unshift({ action: 'delete', file: f.name, time: new Date().toISOString() });

  closeModal();
  showToast(`Deleted "${f.name}"`);
  renderDashboard();
}

/* ─────────────────────────────────────────────
   TOAST
───────────────────────────────────────────── */
let toastTimer;
function showToast(msg, type = 'success') {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = `toast ${type} show`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 3200);
}

/* ─────────────────────────────────────────────
   HELPERS
───────────────────────────────────────────── */
function fmtSize(bytes) {
  if (bytes === 0) return '0 B';
  const k = 1024, sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${(bytes / Math.pow(k, i)).toFixed(1)} ${sizes[i]}`;
}
function fmtGB(gb) { return `${gb.toFixed(2)} GB`; }

function timeAgo(iso) {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1)   return 'just now';
  if (m < 60)  return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24)  return `${h}h ago`;
  const d = Math.floor(h / 24);
  return `${d}d ago`;
}

function esc(str) {
  return (str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function guessType(name) {
  const ext = (name.split('.').pop() || '').toLowerCase();
  if (['jpg','jpeg','png','gif','webp','svg','bmp','ico'].includes(ext)) return 'image';
  if (['pdf','doc','docx','xls','xlsx','ppt','pptx','txt','md','csv'].includes(ext)) return 'document';
  if (['mp4','avi','mov','mkv','webm','flv'].includes(ext)) return 'video';
  if (['mp3','wav','flac','aac','ogg','m4a'].includes(ext)) return 'audio';
  if (['zip','rar','7z','tar','gz','bz2'].includes(ext)) return 'archive';
  return 'other';
}

function typeIcon(type) {
  const icons = {
    image:    '🖼',
    document: '📄',
    video:    '🎬',
    audio:    '🎵',
    archive:  '📦',
    other:    '📁',
  };
  return icons[type] || '📁';
}

function typeColor(type, variant) {
  const map = {
    image:    { dim: 'rgba(0,245,255,0.12)',    solid: 'var(--cyan)' },
    document: { dim: 'rgba(191,0,255,0.12)',    solid: 'var(--purple)' },
    video:    { dim: 'rgba(255,0,110,0.12)',     solid: 'var(--pink)' },
    audio:    { dim: 'rgba(0,245,255,0.10)',     solid: 'var(--cyan)' },
    archive:  { dim: 'rgba(191,0,255,0.10)',     solid: 'var(--purple)' },
    other:    { dim: 'rgba(255,255,255,0.06)',   solid: '#888' },
  };
  return (map[type] || map.other)[variant] || map.other.dim;
}
