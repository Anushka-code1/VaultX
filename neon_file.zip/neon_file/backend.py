"""
VAULTX — backend.py
FastAPI backend with Azure SQL (pyodbc) for file metadata storage.

SETUP:
  pip install fastapi uvicorn pyodbc python-multipart python-dotenv

  Create a .env file with:
    AZURE_SQL_SERVER=<your-server>.database.windows.net
    AZURE_SQL_DATABASE=<your-database>
    AZURE_SQL_USERNAME=<your-username>
    AZURE_SQL_PASSWORD=<your-password>

  Run:
    uvicorn backend:app --reload --port 8000
"""

import os
import uuid
import math
import json
import shutil
from datetime import datetime
from pathlib import Path
from typing import Optional, List

import pyodbc
from dotenv import load_dotenv
from fastapi import FastAPI, File, UploadFile, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel

# ──────────────────────────────────────────────
# Config
# ──────────────────────────────────────────────
load_dotenv()

UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(exist_ok=True)

MAX_FILE_SIZE = 50 * 1024 * 1024   # 50 MB

# ──────────────────────────────────────────────
# Azure SQL Connection
# ──────────────────────────────────────────────
def get_connection():
    """Return a pyodbc connection to Azure SQL Database."""
    server   = os.getenv("AZURE_SQL_SERVER")
    database = os.getenv("AZURE_SQL_DATABASE")
    username = os.getenv("AZURE_SQL_USERNAME")
    password = os.getenv("AZURE_SQL_PASSWORD")

    if not all([server, database, username, password]):
        raise RuntimeError(
            "Missing Azure SQL credentials. Check your .env file:\n"
            "  AZURE_SQL_SERVER, AZURE_SQL_DATABASE, "
            "AZURE_SQL_USERNAME, AZURE_SQL_PASSWORD"
        )

    conn_str = (
        "DRIVER={ODBC Driver 18 for SQL Server};"
        f"SERVER={server},1433;"
        f"DATABASE={database};"
        f"UID={username};"
        f"PWD={password};"
        "Encrypt=yes;"
        "TrustServerCertificate=no;"
        "Connection Timeout=30;"
        "Authentication=ActiveDirectoryPassword"
        "secret_key=name=vault"
    )
    return pyodbc.connect(conn_str)


def init_db():
    """Create tables if they don't exist."""
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        IF NOT EXISTS (
            SELECT * FROM sysobjects WHERE name='files' AND xtype='U'
        )
        CREATE TABLE files (
            id            INT IDENTITY(1,1) PRIMARY KEY,
            file_uuid     NVARCHAR(64)  NOT NULL UNIQUE,
            name          NVARCHAR(255) NOT NULL,
            original_name NVARCHAR(255) NOT NULL,
            size          BIGINT        NOT NULL DEFAULT 0,
            file_type     NVARCHAR(64)  NOT NULL DEFAULT 'other',
            mime_type     NVARCHAR(128),
            description   NVARCHAR(512),
            tags          NVARCHAR(512),
            storage_path  NVARCHAR(512),
            uploaded_at   DATETIME2     NOT NULL DEFAULT GETDATE(),
            deleted       BIT           NOT NULL DEFAULT 0
        )
    """)

    cursor.execute("""
        IF NOT EXISTS (
            SELECT * FROM sysobjects WHERE name='activity_log' AND xtype='U'
        )
        CREATE TABLE activity_log (
            id         INT IDENTITY(1,1) PRIMARY KEY,
            action     NVARCHAR(32)  NOT NULL,
            file_name  NVARCHAR(255) NOT NULL,
            file_id    INT,
            created_at DATETIME2     NOT NULL DEFAULT GETDATE()
        )
    """)

    conn.commit()
    conn.close()


# ──────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────
def detect_type(filename: str) -> str:
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    if ext in {"jpg", "jpeg", "png", "gif", "webp", "svg", "bmp", "ico"}:
        return "image"
    if ext in {"pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "md", "csv"}:
        return "document"
    if ext in {"mp4", "avi", "mov", "mkv", "webm", "flv"}:
        return "video"
    if ext in {"mp3", "wav", "flac", "aac", "ogg", "m4a"}:
        return "audio"
    if ext in {"zip", "rar", "7z", "tar", "gz", "bz2"}:
        return "archive"
    return "other"


def log_activity(cursor, action: str, file_name: str, file_id: int = None):
    cursor.execute(
        "INSERT INTO activity_log (action, file_name, file_id) VALUES (?, ?, ?)",
        (action, file_name, file_id)
    )


def row_to_dict(row, columns) -> dict:
    return {col: (val.isoformat() if isinstance(val, datetime) else val)
            for col, val in zip(columns, row)}


# ──────────────────────────────────────────────
# FastAPI App
# ──────────────────────────────────────────────
app = FastAPI(title="VAULTX API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def startup():
    try:
        init_db()
        print("✅  Azure SQL connection OK — tables ready.")
    except Exception as e:
        print(f"⚠️  DB init failed (demo mode will be used by frontend): {e}")


# ──────────────────────────────────────────────
# Routes
# ──────────────────────────────────────────────

@app.get("/health")
def health():
    """Health check — verifies DB reachability."""
    try:
        conn = get_connection()
        conn.close()
        return {"status": "ok", "db": "connected", "time": datetime.utcnow().isoformat()}
    except Exception as e:
        raise HTTPException(status_code=503, detail=str(e))


# ── List Files ──────────────────────────────
@app.get("/files")
def list_files(search: Optional[str] = None, type: Optional[str] = None):
    conn   = get_connection()
    cursor = conn.cursor()

    query  = "SELECT id, file_uuid, name, original_name, size, file_type, description, tags, uploaded_at FROM files WHERE deleted = 0"
    params = []

    if search:
        query += " AND (original_name LIKE ? OR tags LIKE ? OR description LIKE ?)"
        like   = f"%{search}%"
        params += [like, like, like]

    if type and type != "all":
        query += " AND file_type = ?"
        params.append(type)

    query += " ORDER BY uploaded_at DESC"

    cursor.execute(query, params)
    cols  = [col[0] for col in cursor.description]
    rows  = cursor.fetchall()
    conn.close()

    result = []
    for row in rows:
        d = row_to_dict(row, cols)
        # rename fields frontend expects
        d["type"] = d.pop("file_type")
        d["name"] = d.pop("original_name")
        result.append(d)

    return result


# ── Upload File ─────────────────────────────
@app.post("/files/upload")
async def upload_file(
    file: UploadFile = File(...),
    description: Optional[str] = Form(""),
    tags: Optional[str] = Form(""),
):
    # size guard
    contents = await file.read()
    if len(contents) > MAX_FILE_SIZE:
        raise HTTPException(status_code=413, detail="File exceeds 50 MB limit")

    file_uuid   = str(uuid.uuid4())
    file_type   = detect_type(file.filename)
    safe_name   = f"{file_uuid}_{file.filename}"
    dest_path   = UPLOAD_DIR / safe_name

    # save to disk
    with open(dest_path, "wb") as fp:
        fp.write(contents)

    size = len(contents)

    # save metadata to Azure SQL
    conn   = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        """
        INSERT INTO files
            (file_uuid, name, original_name, size, file_type, mime_type,
             description, tags, storage_path)
        OUTPUT INSERTED.id, INSERTED.uploaded_at
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            file_uuid, safe_name, file.filename, size, file_type,
            file.content_type, description or "", tags or "",
            str(dest_path)
        )
    )
    row = cursor.fetchone()
    new_id      = row[0]
    uploaded_at = row[1]

    log_activity(cursor, "upload", file.filename, new_id)
    conn.commit()
    conn.close()

    return {
        "id":          new_id,
        "file_uuid":   file_uuid,
        "name":        file.filename,
        "size":        size,
        "type":        file_type,
        "description": description,
        "tags":        tags,
        "uploaded_at": uploaded_at.isoformat(),
    }


# ── Get Single File ─────────────────────────
@app.get("/files/{file_id}")
def get_file(file_id: int):
    conn   = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, file_uuid, original_name AS name, size, file_type AS type, "
        "description, tags, uploaded_at FROM files WHERE id = ? AND deleted = 0",
        (file_id,)
    )
    row = cursor.fetchone()
    conn.close()
    if not row:
        raise HTTPException(status_code=404, detail="File not found")
    cols = [col[0] for col in cursor.description]
    return row_to_dict(row, cols)


# ── Download File ───────────────────────────
@app.get("/files/{file_id}/download")
def download_file(file_id: int):
    """Stream the file back to the browser with its original filename."""
    from fastapi.responses import FileResponse

    conn   = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT original_name, storage_path, mime_type FROM files WHERE id = ? AND deleted = 0",
        (file_id,)
    )
    row = cursor.fetchone()

    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail="File not found")

    original_name, storage_path, mime_type = row[0], row[1], row[2]

    # log the download action
    cursor.execute(
        "INSERT INTO activity_log (action, file_name, file_id) VALUES (?, ?, ?)",
        ("download", original_name, file_id)
    )
    conn.commit()
    conn.close()

    path = Path(storage_path)
    if not path.exists():
        raise HTTPException(status_code=404, detail="File not found on disk")

    return FileResponse(
        path=str(path),
        media_type=mime_type or "application/octet-stream",
        filename=original_name,          # triggers Save As with the real name
        headers={
            "Content-Disposition": f'attachment; filename="{original_name}"',
            "Cache-Control": "no-cache",
        }
    )


# ── Delete File ─────────────────────────────
@app.delete("/files/{file_id}")
def delete_file(file_id: int):
    conn   = get_connection()
    cursor = conn.cursor()

    # get storage path
    cursor.execute(
        "SELECT name, storage_path FROM files WHERE id = ? AND deleted = 0",
        (file_id,)
    )
    row = cursor.fetchone()
    if not row:
        conn.close()
        raise HTTPException(status_code=404, detail="File not found")

    original_name, storage_path = row[0], row[1]

    # soft delete in DB
    cursor.execute("UPDATE files SET deleted = 1 WHERE id = ?", (file_id,))
    log_activity(cursor, "delete", original_name, file_id)
    conn.commit()

    # remove from disk (best-effort)
    try:
        if storage_path and Path(storage_path).exists():
            os.remove(storage_path)
    except Exception:
        pass

    conn.close()
    return {"message": f"File {file_id} deleted"}


# ── Storage Stats ────────────────────────────
@app.get("/stats")
def storage_stats():
    conn   = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT
            COUNT(*)       AS total_files,
            COALESCE(SUM(size), 0) AS total_bytes,
            COALESCE(SUM(CASE WHEN file_type = 'image'    THEN size ELSE 0 END), 0) AS image_bytes,
            COALESCE(SUM(CASE WHEN file_type = 'document' THEN size ELSE 0 END), 0) AS doc_bytes,
            COALESCE(SUM(CASE WHEN file_type NOT IN ('image','document') THEN size ELSE 0 END), 0) AS other_bytes,
            COUNT(CASE WHEN CAST(uploaded_at AS DATE) = CAST(GETDATE() AS DATE) THEN 1 END) AS today_uploads
        FROM files
        WHERE deleted = 0
    """)
    row  = cursor.fetchone()
    conn.close()

    total_bytes = row[1]
    max_bytes   = 5 * 1024 ** 3    # 5 GB free tier

    return {
        "total_files":    row[0],
        "total_bytes":    total_bytes,
        "free_bytes":     max(0, max_bytes - total_bytes),
        "image_bytes":    row[2],
        "doc_bytes":      row[3],
        "other_bytes":    row[4],
        "today_uploads":  row[5],
        "usage_pct":      round((total_bytes / max_bytes) * 100, 2),
    }


# ── Activity Log ─────────────────────────────
@app.get("/activity")
def get_activity(limit: int = 30):
    conn   = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT TOP(?) action, file_name AS file, created_at AS time "
        "FROM activity_log ORDER BY created_at DESC",
        (limit,)
    )
    cols = [col[0] for col in cursor.description]
    rows = cursor.fetchall()
    conn.close()
    return [row_to_dict(row, cols) for row in rows]


# ──────────────────────────────────────────────
# Entry point
# ──────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend:app", host="0.0.0.0", port=8000, reload=True)
